import numpy as np
import pandas as pd
df = pd.read_csv("SolarPrediction.csv")
df["Date"] = pd.to_datetime(df["Data"], format="%m/%d/%Y %I:%M:%S %p").dt.normalize()
date_str = df["Date"].dt.strftime("%Y-%m-%d")
df["Datetime"] = pd.to_datetime(date_str + " " + df["Time"])
df["Sunrise"] = pd.to_datetime(date_str + " " + df["TimeSunRise"])
df["Sunset"] = pd.to_datetime(date_str + " " + df["TimeSunSet"])
df = df.sort_values("Datetime").reset_index(drop=True)
print("Datetime column created. Rows:", len(df), "| Dates:", df["Date"].nunique())
print(df[["Datetime", "Radiation"]].head(3), "\n")
daily = df.groupby("Date")["Radiation"].agg(Max_Radiation="max", Avg_Radiation="mean").round(2)
daily.to_csv("daily_report.csv")
print("=== Day-wise solar report (first 10 days) ===")
print(daily.head(10), "\n")
peak_row = df.loc[df["Radiation"].idxmax()]
peak_date = peak_row["Date"]
print("=== Date with highest recorded radiation ===")
print(f"Date          : {peak_date:%d %b %Y}")
print(f"Max radiation : {peak_row['Radiation']:.2f} W/m²\n")
print("=== Conditions at the moment of peak radiation ===")
print(f"Time          : {peak_row['Datetime']:%H:%M:%S}")
print(f"Temperature   : {peak_row['Temperature']} °F")
print(f"Humidity      : {peak_row['Humidity']} %")
print(f"Wind speed    : {peak_row['Speed']} mph\n")
sunrise, sunset, peak_t = peak_row["Sunrise"], peak_row["Sunset"], peak_row["Datetime"]
after_sunrise = peak_t - sunrise
daylight = sunset - sunrise
after_hours = after_sunrise.total_seconds() / 3600
frac = after_sunrise / daylight
solar_noon = sunrise + daylight / 2
print("=== Peak vs sunrise / sunset ===")
print(f"Sunrise       : {sunrise:%H:%M:%S}")
print(f"Sunset        : {sunset:%H:%M:%S}")
print(f"Day length    : {daylight}")
print(f"Peak occurred : {after_sunrise} after sunrise ({np.round(after_hours, 2)} hours)")
print(f"Position      : {np.round(frac * 100, 1)}% of the way through daylight")
print(f"Solar noon (midpoint of sunrise-sunset): {solar_noon:%H:%M:%S}\n")
top5 = daily.sort_values("Avg_Radiation", ascending=False).head(5)
print("=== Top 5 days by average radiation ===")
print(top5)