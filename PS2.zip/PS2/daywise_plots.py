import sys
import os
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
warnings.filterwarnings("ignore", category=RuntimeWarning)
CSV_PATH = "SolarPrediction.csv"
OUT_DIR = "plots"
def load_data(path=CSV_PATH):
    df = pd.read_csv(path)
    df["Date"] = pd.to_datetime(df["Data"], format="%m/%d/%Y %I:%M:%S %p").dt.normalize()
    df["Datetime"] = pd.to_datetime(df["Date"].dt.strftime("%Y-%m-%d") + " " + df["Time"])
    df["Sunrise"] = pd.to_datetime(df["Date"].dt.strftime("%Y-%m-%d") + " " + df["TimeSunRise"])
    df["Sunset"] = pd.to_datetime(df["Date"].dt.strftime("%Y-%m-%d") + " " + df["TimeSunSet"])
    df = df.sort_values("Datetime").reset_index(drop=True)
    return df
PARAMS = [("Temperature",            "Temperature (°F)",       "tab:red"), ("Humidity",               "Humidity (%)",           "tab:blue"), ("Speed",                  "Wind Speed (mph)",       "tab:green"), ("Pressure",               "Pressure (inHg)",        "tab:purple"), ("WindDirection(Degrees)", "Wind Direction (°)",     "tab:orange")]
def plot_day(df, date, out_dir=OUT_DIR, show_outliers=True):
    date = pd.Timestamp(date).normalize()
    day = df[df["Date"] == date].sort_values("Datetime")
    if day.empty:
        print(f"[skip] no data for {date.date()}")
        return None
    fig, axes = plt.subplots(2, 3, figsize=(18, 9))
    fig.suptitle(f"Solar radiation analysis - {date.strftime('%d %b %Y')}", fontsize=16, fontweight="bold")
    ax = axes[0, 0]
    ax.plot(day["Datetime"], day["Radiation"], color="goldenrod", lw=1.8)
    ax.fill_between(day["Datetime"], day["Radiation"], color="gold", alpha=0.3)
    sunrise, sunset = day["Sunrise"].iloc[0], day["Sunset"].iloc[0]
    ax.axvline(sunrise, color="orange", ls="--", label="Sunrise")
    ax.axvline(sunset, color="darkred", ls="--", label="Sunset")
    peak = day.loc[day["Radiation"].idxmax()]
    ax.scatter(peak["Datetime"], peak["Radiation"], color="black", zorder=5, label=f"Peak {peak['Radiation']:.0f} W/m² @ {peak['Datetime']:%H:%M}")
    if show_outliers:
        q1, q3 = day["Radiation"].quantile([0.25, 0.75])
        upper = q3 + 1.5 * (q3 - q1)
        out = day[day["Radiation"] > upper]
        if not out.empty:
            ax.scatter(out["Datetime"], out["Radiation"], color="red", s=18, zorder=4, label=f"Outliers (IQR rule): {len(out)}")
    ax.set_title("Radiation vs Time of day")
    ax.set_xlabel("Time")
    ax.set_ylabel("Radiation (W/m²)")
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
    ax.xaxis.set_major_locator(mdates.HourLocator(interval=4))
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3)
    slots = [axes[0, 1], axes[0, 2], axes[1, 0], axes[1, 1], axes[1, 2]]
    for ax, (col, label, colour) in zip(slots, PARAMS):
        x, y = day[col], day["Radiation"]
        sc = ax.scatter(x, y, c=day["Datetime"].dt.hour, cmap="viridis", s=14, alpha=0.8)
        if x.nunique() > 1:
            m, b = np.polyfit(x, y, 1)
            xs = np.linspace(x.min(), x.max(), 100)
            ax.plot(xs, m * xs + b, color=colour, lw=2)
            r = np.corrcoef(x, y)[0, 1]
            ax.set_title(f"Radiation vs {label.split(' (')[0]}  (r = {r:.2f})")
        else:
            ax.set_title(f"Radiation vs {label.split(' (')[0]}  (r = n/a)")
        ax.set_xlabel(label)
        ax.set_ylabel("Radiation (W/m²)")
        ax.grid(alpha=0.3)
    cbar = fig.colorbar(sc, ax=axes, shrink=0.6, pad=0.01)
    cbar.set_label("Hour of day")
    os.makedirs(out_dir, exist_ok=True)
    fname = os.path.join(out_dir, f"day_{date:%Y-%m-%d}.png")
    fig.savefig(fname, dpi=110, bbox_inches="tight")
    plt.close(fig)
    return fname
def daily_correlations(df):
    rows = []
    for date, day in df.groupby("Date"):
        row = {"Date": date.date(), "n_obs": len(day), "peak_radiation": day["Radiation"].max(), "peak_time": day.loc[day["Radiation"].idxmax(), "Datetime"].strftime("%H:%M")}
        for col, *_ in PARAMS:
            row[f"corr_{col}"] = day["Radiation"].corr(day[col])
        corr_cols = [f"corr_{c}" for c, *_ in PARAMS]
        row["strongest_param"] = (pd.Series(row, index=corr_cols).abs().idxmax().replace("corr_", ""))
        rows.append(row)
    return pd.DataFrame(rows)
if __name__ == "__main__":
    data = load_data()
    all_dates = sorted(data["Date"].unique())
    if len(sys.argv) > 1:
        dates = [pd.Timestamp(a) for a in sys.argv[1:]]
    else:
        dates = all_dates
    for d in dates:
        f = plot_day(data, d)
        if f:
            print("saved", f)
    summary = daily_correlations(data)
    summary.to_csv("daily_correlations.csv", index=False)
    print("\nStrongest correlating parameter (count of days):")
    print(summary["strongest_param"].value_counts())